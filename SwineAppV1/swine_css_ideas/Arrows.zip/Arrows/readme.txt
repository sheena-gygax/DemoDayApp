------------------------------------------------------------
This resource has been created by Alessio Atzeni for AlessioAtzeni.com
------------------------------------------------------------

TERMS OF USE:

All resources made available on Alessio Atzeni are free for use in both personal and commercial projects.

You may freely use our resources, without restriction, in software programs, web templates and other materials intended for sale or distribution. 

No attribution or backlinks are required, but any form of spreading the word is always appreciated!

You are not permitted to make the resources available for distribution elsewhere “as is” without prior consent.

Alessio Atzeni

PS: Dont'miss my last project "Pyconic" http://www.pyconic.com
768 Royalty-free vector icons, raster and font formats. When Pyconic launch 400 PNG Free Icons at 32px for your trouble. :)

----------------------------------
URL: www.alessioatzeni.com
BLOG: www.alessioatzeni.com/blog/
@TWITTER: @Bluxart
@EMAIL: info@alessioatzeni.com
----------------------------------